export interface Song {
  id: string;
  title: string;
  artist: string; // Usually "SonoAI"
  imageUrl: string;
  lyrics: string;
  style: string;
  duration: number; // in seconds
  status: 'generating' | 'ready' | 'error';
  createdAt: number;
  audioUrl?: string; // Mock URL for playback
  isInstrumental: boolean;
}

export interface CreateSongParams {
  prompt: string;
  isCustom: boolean;
  customLyrics: string;
  customStyle: string;
  customTitle: string;
  isInstrumental: boolean;
}

export interface GeneratedMetadata {
  title: string;
  lyrics: string;
  styleTags: string[];
  description: string;
}
