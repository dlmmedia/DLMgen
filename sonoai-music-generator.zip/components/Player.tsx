import React, { useRef, useEffect, useState } from 'react';
import { Play, Pause, SkipBack, SkipForward, Repeat, Shuffle, Volume2, Mic2 } from 'lucide-react';
import { Song } from '../types';

interface PlayerProps {
  currentSong: Song | null;
  isPlaying: boolean;
  onPlayPause: () => void;
  onNext: () => void;
  onPrev: () => void;
}

export const Player: React.FC<PlayerProps> = ({ currentSong, isPlaying, onPlayPause, onNext, onPrev }) => {
  const audioRef = useRef<HTMLAudioElement | null>(null);
  const [progress, setProgress] = useState(0);
  const [duration, setDuration] = useState(0);

  // Reliable fallback URL if the song url fails
  const FALLBACK_URL = 'https://storage.googleapis.com/automotive-media/Jazz_In_Paris.mp3';

  // Effect to handle Play/Pause based on isPlaying prop
  useEffect(() => {
    const audio = audioRef.current;
    if (!audio) return;

    if (isPlaying) {
      const playPromise = audio.play();
      if (playPromise !== undefined) {
        playPromise.catch(error => {
          // Swallow the error or log a simple string to avoid circular structure issues
          console.warn("Playback prevented:", error instanceof Error ? error.message : "Unknown error");
        });
      }
    } else {
      audio.pause();
    }
  }, [isPlaying, currentSong]); // Depend on currentSong to retry play if song changes

  const handleTimeUpdate = () => {
    if (audioRef.current) {
      setProgress(audioRef.current.currentTime);
      setDuration(audioRef.current.duration || 0);
    }
  };

  const handleSeek = (e: React.ChangeEvent<HTMLInputElement>) => {
    const time = parseFloat(e.target.value);
    if (audioRef.current) {
      audioRef.current.currentTime = time;
      setProgress(time);
    }
  };

  const handleError = (e: React.SyntheticEvent<HTMLAudioElement, Event>) => {
    // Avoid logging the entire event object to prevent circular structure errors
    const target = e.currentTarget;
    if (target.error) {
      console.error(`Audio Error: Code ${target.error.code} - ${target.error.message}`);
      
      // Attempt to recover if it's a specific load error (Code 4 = MEDIA_ERR_SRC_NOT_SUPPORTED)
      // Only retry if we haven't already switched to the fallback
      if (target.error.code === 4 && target.src !== FALLBACK_URL) {
         console.log("Format error or source not found. Switching to fallback...");
         target.src = FALLBACK_URL;
         if(isPlaying) {
             target.play().catch(console.warn);
         }
      }
    }
  };

  const formatTime = (time: number) => {
    if(isNaN(time)) return "0:00";
    const min = Math.floor(time / 60);
    const sec = Math.floor(time % 60).toString().padStart(2, '0');
    return `${min}:${sec}`;
  };

  if (!currentSong) return null;

  return (
    <div className="fixed bottom-0 left-0 right-0 h-24 bg-[#18181b] border-t border-white/5 px-4 flex items-center justify-between z-50">
      <audio 
        key={currentSong.id} /* CRITICAL: Forces full reload of audio element on song change */
        ref={audioRef} 
        src={currentSong.audioUrl || FALLBACK_URL}
        onTimeUpdate={handleTimeUpdate} 
        onEnded={onNext}
        onError={handleError}
        preload="auto"
        playsInline
      />
      
      {/* Track Info */}
      <div className="flex items-center gap-4 w-1/4 min-w-[200px]">
        <img 
            src={currentSong.imageUrl} 
            alt="cover" 
            className="w-14 h-14 rounded-md object-cover shadow-md"
        />
        <div className="overflow-hidden">
            <h4 className="text-white font-bold text-sm truncate">{currentSong.title}</h4>
            <p className="text-gray-400 text-xs truncate">{currentSong.artist}</p>
        </div>
      </div>

      {/* Controls & Progress */}
      <div className="flex flex-col items-center flex-1 max-w-2xl px-4">
        <div className="flex items-center gap-6 mb-2">
            <button className="text-gray-400 hover:text-white transition-colors"><Shuffle size={18} /></button>
            <button onClick={onPrev} className="text-gray-200 hover:text-white transition-colors"><SkipBack size={24} fill="currentColor" /></button>
            <button 
                onClick={onPlayPause}
                className="w-10 h-10 bg-white rounded-full flex items-center justify-center hover:scale-105 transition-transform"
            >
                {isPlaying ? <Pause size={20} className="text-black fill-current" /> : <Play size={20} className="text-black fill-current ml-1" />}
            </button>
            <button onClick={onNext} className="text-gray-200 hover:text-white transition-colors"><SkipForward size={24} fill="currentColor" /></button>
            <button className="text-gray-400 hover:text-white transition-colors"><Repeat size={18} /></button>
        </div>
        
        <div className="w-full flex items-center gap-3 text-xs text-gray-400 font-mono">
            <span className="w-8 text-right">{formatTime(progress)}</span>
            <input 
                type="range" 
                min="0" 
                max={duration || 100} 
                value={progress} 
                onChange={handleSeek}
                className="flex-1 h-1 bg-gray-600 rounded-lg appearance-none cursor-pointer [&::-webkit-slider-thumb]:appearance-none [&::-webkit-slider-thumb]:w-3 [&::-webkit-slider-thumb]:h-3 [&::-webkit-slider-thumb]:bg-white [&::-webkit-slider-thumb]:rounded-full hover:[&::-webkit-slider-thumb]:scale-125 transition-all"
            />
            <span className="w-8">{formatTime(duration)}</span>
        </div>
      </div>

      {/* Volume & Extras */}
      <div className="w-1/4 flex items-center justify-end gap-4 min-w-[200px]">
         {/* Lyrics Button (simulated) */}
         <button className="text-gray-400 hover:text-white">
            <Mic2 size={20} />
         </button>
         <div className="flex items-center gap-2 group">
            <Volume2 size={20} className="text-gray-400" />
            <div className="w-24 h-1 bg-gray-600 rounded-full overflow-hidden">
                <div className="w-3/4 h-full bg-gray-400 group-hover:bg-primary transition-colors"></div>
            </div>
         </div>
      </div>
    </div>
  );
};