import React, { useState } from 'react';
import { Mic, Music, Sparkles, X } from 'lucide-react';
import { CreateSongParams } from '../types';

interface CreateFormProps {
  onSubmit: (params: CreateSongParams) => void;
  isGenerating: boolean;
}

export const CreateForm: React.FC<CreateFormProps> = ({ onSubmit, isGenerating }) => {
  const [isCustom, setIsCustom] = useState(false);
  const [prompt, setPrompt] = useState('');
  const [isInstrumental, setIsInstrumental] = useState(false);
  
  // Custom mode states
  const [lyrics, setLyrics] = useState('');
  const [style, setStyle] = useState('');
  const [title, setTitle] = useState('');

  const handleSubmit = () => {
    if ((!isCustom && !prompt) || (isCustom && !lyrics && !isInstrumental && !style)) return;
    
    onSubmit({
      prompt: isCustom ? (style + " " + title) : prompt,
      isCustom,
      customLyrics: lyrics,
      customStyle: style,
      customTitle: title,
      isInstrumental
    });
    
    // Reset minimal fields
    if (!isCustom) setPrompt('');
  };

  return (
    <div className="bg-surface rounded-lg p-0 flex flex-col h-full overflow-y-auto">
        <div className="p-4 border-b border-white/5 flex items-center justify-between sticky top-0 bg-surface z-10">
            <h2 className="text-xl font-bold">Create</h2>
            <div className="flex items-center gap-2 text-sm bg-black/20 p-1 rounded-lg">
                <button 
                    onClick={() => setIsCustom(false)}
                    className={`px-3 py-1 rounded-md transition-all ${!isCustom ? 'bg-white/10 text-white shadow-sm' : 'text-gray-400 hover:text-white'}`}
                >
                    Simple
                </button>
                <button 
                    onClick={() => setIsCustom(true)}
                    className={`px-3 py-1 rounded-md transition-all ${isCustom ? 'bg-white/10 text-white shadow-sm' : 'text-gray-400 hover:text-white'}`}
                >
                    Custom
                </button>
            </div>
        </div>

        <div className="p-6 flex-1 flex flex-col gap-6">
            
            {/* Custom Toggle Switch (Visual for Custom Mode) */}
            <div className="flex items-center justify-between">
                <span className="text-gray-400 text-sm font-medium">Custom Mode</span>
                <div 
                    onClick={() => setIsCustom(!isCustom)}
                    className={`w-12 h-6 rounded-full p-1 cursor-pointer transition-colors ${isCustom ? 'bg-primary' : 'bg-gray-700'}`}
                >
                    <div className={`w-4 h-4 rounded-full bg-white shadow-sm transition-transform ${isCustom ? 'translate-x-6' : 'translate-x-0'}`} />
                </div>
            </div>

            {isCustom ? (
                // CUSTOM MODE
                <>
                    {/* Lyrics Section */}
                    <div className="space-y-2">
                         <div className="flex items-center justify-between">
                            <label className="text-sm font-bold text-gray-300">Lyrics</label>
                            <div className="flex items-center gap-2">
                                <span className="text-xs text-gray-500">Instrumental</span>
                                <div 
                                    onClick={() => setIsInstrumental(!isInstrumental)}
                                    className={`w-10 h-5 rounded-full p-1 cursor-pointer transition-colors ${isInstrumental ? 'bg-green-500' : 'bg-gray-700'}`}
                                >
                                    <div className={`w-3 h-3 rounded-full bg-white shadow-sm transition-transform ${isInstrumental ? 'translate-x-5' : 'translate-x-0'}`} />
                                </div>
                            </div>
                        </div>
                        
                        {!isInstrumental ? (
                            <textarea 
                                value={lyrics}
                                onChange={(e) => setLyrics(e.target.value)}
                                placeholder="Enter your own lyrics or describe a topic..."
                                className="w-full h-40 bg-black/20 border border-white/10 rounded-lg p-3 text-sm text-white placeholder-gray-500 focus:outline-none focus:border-primary resize-none"
                            />
                        ) : (
                            <div className="w-full h-40 bg-black/20 border border-white/10 rounded-lg p-3 flex items-center justify-center text-gray-500 italic text-sm">
                                Instrumental track - no lyrics will be generated.
                            </div>
                        )}
                        {!isInstrumental && (
                             <button 
                                className="text-xs text-primary hover:text-primary/80 flex items-center gap-1 font-medium"
                                onClick={() => setLyrics("[Verse 1]\nNeon lights in the rain\nWalking down the memory lane\n\n[Chorus]\nDigital dreams, silent screams\nNothing is ever what it seems")}
                            >
                                <Sparkles size={12} /> Generate random lyrics
                             </button>
                        )}
                    </div>

                    {/* Style Section */}
                    <div className="space-y-2">
                        <label className="text-sm font-bold text-gray-300">Style of Music</label>
                        <textarea 
                            value={style}
                            onChange={(e) => setStyle(e.target.value)}
                            placeholder="e.g. 80s pop, upbeat, female vocals, synthwave..."
                            className="w-full h-20 bg-black/20 border border-white/10 rounded-lg p-3 text-sm text-white placeholder-gray-500 focus:outline-none focus:border-primary resize-none"
                        />
                        <div className="flex gap-2 flex-wrap">
                            {['Electronic', 'Jazz', 'Rock', 'Lofi'].map(tag => (
                                <button 
                                    key={tag}
                                    onClick={() => setStyle(prev => prev ? `${prev}, ${tag}` : tag)}
                                    className="px-2 py-1 bg-white/5 hover:bg-white/10 rounded-full text-xs text-gray-400 border border-white/5"
                                >
                                    {tag}
                                </button>
                            ))}
                        </div>
                    </div>

                     {/* Title Section */}
                     <div className="space-y-2">
                        <label className="text-sm font-bold text-gray-300">Title</label>
                        <input 
                            value={title}
                            onChange={(e) => setTitle(e.target.value)}
                            placeholder="Give it a name (optional)"
                            className="w-full bg-black/20 border border-white/10 rounded-lg p-3 text-sm text-white placeholder-gray-500 focus:outline-none focus:border-primary"
                        />
                    </div>
                </>
            ) : (
                // SIMPLE MODE
                <div className="space-y-2">
                    <label className="text-sm font-bold text-gray-300">Song Description</label>
                    <textarea 
                        value={prompt}
                        onChange={(e) => setPrompt(e.target.value)}
                        placeholder="A sad song about a robot who falls in love with a toaster..."
                        className="w-full h-40 bg-black/20 border border-white/10 rounded-lg p-3 text-sm text-white placeholder-gray-500 focus:outline-none focus:border-primary resize-none"
                    />
                     <div className="flex items-center gap-2 mt-2">
                         <span className="text-xs text-gray-500">Instrumental</span>
                         <div 
                             onClick={() => setIsInstrumental(!isInstrumental)}
                             className={`w-8 h-4 rounded-full p-0.5 cursor-pointer transition-colors ${isInstrumental ? 'bg-green-500' : 'bg-gray-700'}`}
                         >
                             <div className={`w-3 h-3 rounded-full bg-white shadow-sm transition-transform ${isInstrumental ? 'translate-x-4' : 'translate-x-0'}`} />
                         </div>
                    </div>
                </div>
            )}
        </div>
        
        {/* Footer Actions */}
        <div className="p-4 border-t border-white/5 bg-surface sticky bottom-0">
             <div className="flex items-center justify-between mb-4 text-xs text-gray-500">
                <span>0 credits used</span>
                <span>120 credits remaining</span>
             </div>
             <button
                onClick={handleSubmit}
                disabled={isGenerating}
                className={`w-full py-3 rounded-lg font-bold text-white flex items-center justify-center gap-2 transition-all
                    ${isGenerating 
                        ? 'bg-gray-600 cursor-not-allowed' 
                        : 'bg-primary hover:bg-purple-600 shadow-[0_0_15px_rgba(168,85,247,0.4)] hover:shadow-[0_0_25px_rgba(168,85,247,0.6)]'
                    }
                `}
             >
                {isGenerating ? (
                    <>
                        <div className="w-4 h-4 border-2 border-white/30 border-t-white rounded-full animate-spin" />
                        Creating...
                    </>
                ) : (
                    <>
                        <Sparkles className="w-4 h-4 fill-current" />
                        Create
                    </>
                )}
             </button>
        </div>
    </div>
  );
};
