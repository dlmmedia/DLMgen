import React, { useState } from 'react';
import { Menu, Library, Disc, Search, User, Music } from 'lucide-react';
import { CreateForm } from './components/CreateForm';
import { SongCard } from './components/SongCard';
import { Player } from './components/Player';
import { Song, CreateSongParams } from './types';
import { generateSongMetadata, generateAlbumArt } from './services/gemini';
import { v4 as uuidv4 } from 'uuid'; // We don't have uuid installed, using simple random string
const simpleId = () => Math.random().toString(36).substr(2, 9);

// --- Audio Library for Smart Selection (Using reliable Google Storage URLs) ---
const AUDIO_LIBRARY = [
  {
    url: 'https://storage.googleapis.com/uamp/The_Kyoto_Connection_-_Wake_Up/01_-_Intro_-_The_Way_Of_Waking_Up_feat_Alan_Watts.mp3',
    tags: ['chill', 'relax', 'study', 'minimal', 'electronic', 'lofi', 'night', 'intro']
  },
  {
    url: 'https://storage.googleapis.com/uamp/The_Kyoto_Connection_-_Wake_Up/02_-_Geisha.mp3',
    tags: ['asian', 'world', 'fusion', 'beat', 'mysterious', 'travel', 'electronic']
  },
  {
    url: 'https://storage.googleapis.com/automotive-media/Jazz_In_Paris.mp3',
    tags: ['jazz', 'lounge', 'smooth', 'cafe', 'retro', 'sax', 'classy', 'instrumental']
  },
  {
    url: 'https://storage.googleapis.com/automotive-media/The_Messenger.mp3',
    tags: ['sad', 'emotional', 'piano', 'cinematic', 'ambient', 'slow', 'dark', 'melancholy', 'depression']
  },
  {
    url: 'https://storage.googleapis.com/uamp/The_Kyoto_Connection_-_Wake_Up/03_-_Voyage_I_-_Waterfall.mp3',
    tags: ['upbeat', 'pop', 'happy', 'energetic', 'dance', 'summer', 'fun', 'joy']
  },
  {
    url: 'https://storage.googleapis.com/automotive-media/Talkies.mp3',
    tags: ['rock', 'guitar', 'band', 'alternative', 'indie', 'upbeat']
  },
  {
     url: 'https://storage.googleapis.com/uamp/Kai_Engel_-_Irsen_s_Tale/04_-_Moonlight_Reprise.mp3',
     tags: ['acoustic', 'folk', 'guitar', 'warm', 'kind', 'soft', 'classical']
  }
];

// Helper to select track based on text analysis
function selectTrack(description: string, styles: string[] = []): string {
    const text = (description + ' ' + styles.join(' ')).toLowerCase();
    
    let bestMatch = AUDIO_LIBRARY[0];
    let maxScore = -1;

    AUDIO_LIBRARY.forEach(track => {
        let score = 0;
        track.tags.forEach(tag => {
            if (text.includes(tag)) score += 5; // Exact tag match is high value
        });
        
        // Add a little randomness to break ties or vary results slightly
        score += Math.random(); 

        if (score > maxScore) {
            maxScore = score;
            bestMatch = track;
        }
    });

    console.log(`Selected track for "${description}":`, bestMatch.tags);
    return bestMatch.url;
}


// Mock Data for Library
const MOCK_SONGS: Song[] = [
  {
    id: '1',
    title: 'Waking Up',
    artist: 'SonoAI',
    imageUrl: 'https://picsum.photos/id/10/300/300',
    lyrics: '[Instrumental]',
    style: 'Electronic, Minimal, Chill',
    duration: 184,
    status: 'ready',
    createdAt: Date.now(),
    audioUrl: AUDIO_LIBRARY[0].url,
    isInstrumental: true
  },
  {
    id: '2',
    title: 'Neon Drift',
    artist: 'SonoAI',
    imageUrl: 'https://picsum.photos/id/15/300/300',
    lyrics: '[Verse]\nComputing the future\nOne bit at a time...',
    style: 'Electronic, Synth, Arpeggiator',
    duration: 145,
    status: 'ready',
    createdAt: Date.now() - 10000,
    audioUrl: AUDIO_LIBRARY[1].url,
    isInstrumental: false
  }
];

export default function App() {
  const [activeTab, setActiveTab] = useState<'create' | 'library' | 'explore'>('create');
  const [songs, setSongs] = useState<Song[]>(MOCK_SONGS);
  const [currentSong, setCurrentSong] = useState<Song | null>(null);
  const [isPlaying, setIsPlaying] = useState(false);
  const [isGenerating, setIsGenerating] = useState(false);
  const [sidebarOpen, setSidebarOpen] = useState(false); // Mobile

  const handleCreate = async (params: CreateSongParams) => {
    setIsGenerating(true);
    
    const newId = simpleId();
    // Optimistic update
    const tempSong: Song = {
      id: newId,
      title: 'Generating...',
      artist: 'SonoAI',
      imageUrl: 'https://i.gifer.com/ZZ5H.gif', // loading placeholder
      lyrics: '',
      style: 'Processing...',
      duration: 120,
      status: 'generating',
      createdAt: Date.now(),
      isInstrumental: params.isInstrumental
    };

    setSongs([tempSong, ...songs]);

    try {
      // 1. Generate Metadata
      const metadata = await generateSongMetadata(
        params.prompt, 
        params.isInstrumental, 
        params.customLyrics, 
        params.customStyle, 
        params.customTitle
      );

      // 2. Generate Art (parallel-ish)
      const imageUrl = await generateAlbumArt(metadata.description);

      // 3. "Synthesize" audio (Select smart track based on prompt/style)
      const fullPrompt = `${params.prompt} ${params.customStyle || ''} ${metadata.styleTags.join(' ')}`;
      const selectedTrackUrl = selectTrack(fullPrompt, metadata.styleTags);

      const finalSong: Song = {
        ...tempSong,
        title: metadata.title,
        lyrics: metadata.lyrics,
        style: metadata.styleTags.join(', '),
        imageUrl: imageUrl,
        status: 'ready',
        audioUrl: selectedTrackUrl,
        duration: 120 + Math.floor(Math.random() * 60) // Random duration
      };

      setSongs(prev => prev.map(s => s.id === newId ? finalSong : s));
      
    } catch (err) {
      console.error(err);
      setSongs(prev => prev.map(s => s.id === newId ? { ...s, title: 'Error Generation', status: 'error' } : s));
    } finally {
      setIsGenerating(false);
    }
  };

  const playSong = (song: Song) => {
    if (currentSong?.id === song.id) {
      setIsPlaying(true);
    } else {
      setCurrentSong(song);
      setIsPlaying(true);
    }
  };

  const pauseSong = () => {
    setIsPlaying(false);
  };

  const togglePlayPause = () => {
    if (isPlaying) pauseSong();
    else if (currentSong) playSong(currentSong);
  };

  const nextSong = () => {
      if(!currentSong) return;
      const idx = songs.findIndex(s => s.id === currentSong.id);
      if(idx > -1 && idx < songs.length - 1) playSong(songs[idx+1]);
      else playSong(songs[0]); // Loop
  };

  const prevSong = () => {
    if(!currentSong) return;
    const idx = songs.findIndex(s => s.id === currentSong.id);
    if(idx > 0) playSong(songs[idx-1]);
  };

  return (
    <div className="flex h-screen bg-black text-white overflow-hidden font-sans">
      {/* Sidebar */}
      <aside className={`
        fixed inset-y-0 left-0 z-40 w-64 bg-sidebar border-r border-white/5 transform transition-transform duration-300 ease-in-out
        ${sidebarOpen ? 'translate-x-0' : '-translate-x-full'} md:translate-x-0 md:static
      `}>
        <div className="p-6 flex items-center gap-2">
            <div className="w-8 h-8 rounded-full bg-gradient-to-br from-primary to-purple-800 flex items-center justify-center">
                <Disc className="text-white animate-pulse" size={20} />
            </div>
            <h1 className="text-xl font-bold tracking-tight">SonoAI</h1>
        </div>

        <nav className="px-3 space-y-1">
            <button 
                onClick={() => setActiveTab('create')}
                className={`w-full flex items-center gap-3 px-3 py-2 rounded-md transition-colors ${activeTab === 'create' ? 'bg-white/10 text-white font-medium' : 'text-gray-400 hover:text-white hover:bg-white/5'}`}
            >
                <Disc size={20} />
                Create
            </button>
            <button 
                onClick={() => setActiveTab('library')}
                className={`w-full flex items-center gap-3 px-3 py-2 rounded-md transition-colors ${activeTab === 'library' ? 'bg-white/10 text-white font-medium' : 'text-gray-400 hover:text-white hover:bg-white/5'}`}
            >
                <Library size={20} />
                Library
            </button>
            <button 
                onClick={() => setActiveTab('explore')}
                className={`w-full flex items-center gap-3 px-3 py-2 rounded-md transition-colors ${activeTab === 'explore' ? 'bg-white/10 text-white font-medium' : 'text-gray-400 hover:text-white hover:bg-white/5'}`}
            >
                <Search size={20} />
                Explore
            </button>
        </nav>

        <div className="absolute bottom-0 left-0 right-0 p-4 border-t border-white/5">
            <div className="flex items-center gap-3 text-sm text-gray-400 hover:text-white cursor-pointer p-2 rounded-md hover:bg-white/5">
                <div className="w-8 h-8 rounded-full bg-gray-700 flex items-center justify-center">
                    <User size={16} />
                </div>
                <div>
                    <div className="font-medium text-white">Guest User</div>
                    <div className="text-xs">Free Plan</div>
                </div>
            </div>
        </div>
      </aside>

      {/* Main Content */}
      <main className="flex-1 flex flex-col relative min-w-0">
        {/* Mobile Header */}
        <div className="md:hidden flex items-center p-4 border-b border-white/5 bg-sidebar">
            <button onClick={() => setSidebarOpen(!sidebarOpen)}>
                <Menu className="text-gray-400" />
            </button>
            <span className="ml-4 font-bold">SonoAI</span>
        </div>

        <div className="flex-1 overflow-hidden relative">
            {activeTab === 'create' ? (
                <div className="h-full flex flex-col md:flex-row">
                    {/* Left: Form */}
                    <div className="w-full md:w-[400px] lg:w-[450px] border-r border-white/5 h-full bg-surface z-10 shadow-xl">
                        <CreateForm onSubmit={handleCreate} isGenerating={isGenerating} />
                    </div>
                    
                    {/* Right: Output/Feed */}
                    <div className="flex-1 bg-black h-full overflow-y-auto">
                        <div className="p-6 md:p-8 max-w-5xl mx-auto">
                           <h2 className="text-2xl font-bold mb-6">Recently Created</h2>
                           <div className="space-y-2">
                               {songs.length === 0 ? (
                                   <div className="text-center text-gray-500 py-20">
                                       <Music className="w-16 h-16 mx-auto mb-4 opacity-20" />
                                       <p>Your musical journey starts here.</p>
                                   </div>
                               ) : (
                                   songs.map(song => (
                                       <SongCard 
                                            key={song.id} 
                                            song={song} 
                                            isActive={currentSong?.id === song.id}
                                            isPlaying={isPlaying}
                                            onPlay={playSong}
                                            onPause={pauseSong}
                                       />
                                   ))
                               )}
                           </div>
                        </div>
                    </div>
                </div>
            ) : activeTab === 'library' ? (
                <div className="p-8 h-full overflow-y-auto">
                    <h2 className="text-3xl font-bold mb-8">Your Library</h2>
                     <div className="space-y-2 max-w-5xl mx-auto">
                        {songs.map(song => (
                            <SongCard 
                                key={song.id} 
                                song={song} 
                                isActive={currentSong?.id === song.id}
                                isPlaying={isPlaying}
                                onPlay={playSong}
                                onPause={pauseSong}
                            />
                        ))}
                    </div>
                </div>
            ) : (
                <div className="flex items-center justify-center h-full text-gray-500">
                    <div className="text-center">
                         <h2 className="text-2xl font-bold text-white mb-2">Explore Coming Soon</h2>
                         <p>Discover trending tracks from the community.</p>
                    </div>
                </div>
            )}
        </div>

        {/* Player Spacer */}
        {currentSong && <div className="h-24 flex-shrink-0" />} 
      </main>

      {/* Sticky Player */}
      <Player 
        currentSong={currentSong} 
        isPlaying={isPlaying} 
        onPlayPause={togglePlayPause} 
        onNext={nextSong}
        onPrev={prevSong}
      />
    </div>
  );
}